<?php
$name=$dbo=$address=$contact=$qualifications=$experiance="";
$username = "root";
$password = "";
$database = "employeedb";
 
$mysqli = new mysqli("localhost", $username, $password, $database);
 
// Don't forget to properly escape your values before you send them to DB
// to prevent SQL injection attacks.

$name = $mysqli->real_escape_string($_POST['name']);
$dob = $mysqli->real_escape_string($_POST['dob']);
$address = $mysqli->real_escape_string($_POST['address']);
$contact = $mysqli->real_escape_string($_POST['contact']);
$qualifications = $mysqli->real_escape_string($_POST['qualifications']);
$experiance = $mysqli->real_escape_string($_POST['experiance']);

$query = "INSERT INTO employeetbl (name, dob, address, contact, qualifications, experiance)
            VALUES ('{$name}','{$dob}','{$address}','{$contact}','{$qualifications}','{$experiance}')";
 
$mysqli->query($query);
$mysqli->close();
?>